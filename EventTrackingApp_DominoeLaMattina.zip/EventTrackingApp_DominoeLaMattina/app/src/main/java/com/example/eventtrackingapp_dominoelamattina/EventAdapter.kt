package com.example.eventtrackingapp_dominoelamattina

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** RecyclerView adapter showing events in a 2-col grid. */
class EventAdapter(
    private val items: MutableList<Event>,
    private val onClick: (Event) -> Unit,
    private val onLongClick: (Event) -> Unit
) : RecyclerView.Adapter<EventAdapter.VH>() {

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.textItemTitle)
        val subtitle: TextView = itemView.findViewById(R.id.textItemSubtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_event, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.title.text = e.name
        holder.subtitle.text = e.date
        holder.itemView.setOnClickListener { onClick(e) }
        holder.itemView.setOnLongClickListener { onLongClick(e); true }
    }

    override fun getItemCount(): Int = items.size

    fun replaceAll(newItems: List<Event>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}