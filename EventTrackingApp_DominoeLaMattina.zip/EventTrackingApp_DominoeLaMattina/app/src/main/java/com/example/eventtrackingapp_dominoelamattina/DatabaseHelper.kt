package com.example.eventtrackingapp_dominoelamattina

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** SQLite helper for users + events (CRUD). */
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "event_app.db"
        private const val DATABASE_VERSION = 1

        // Users
        const val T_USERS = "users"
        const val C_USERNAME = "username"
        const val C_PASSWORD = "password"

        // Events
        const val T_EVENTS = "events"
        const val C_ID = "id"
        const val C_NAME = "eventName"
        const val C_DATE = "eventDate"       // "YYYY-MM-DD HH:MM"
        const val C_LOCATION = "eventLocation"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE $T_USERS (" +
                    "$C_USERNAME TEXT PRIMARY KEY, " +
                    "$C_PASSWORD TEXT NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE $T_EVENTS (" +
                    "$C_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$C_NAME TEXT NOT NULL, " +
                    "$C_DATE TEXT NOT NULL, " +
                    "$C_LOCATION TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $T_USERS")
        db.execSQL("DROP TABLE IF EXISTS $T_EVENTS")
        onCreate(db)
    }

    // ===== Users =====
    fun insertUser(username: String, password: String): Boolean {
        val values = ContentValues().apply {
            put(C_USERNAME, username.trim())
            put(C_PASSWORD, password)
        }
        return writableDatabase.insert(T_USERS, null, values) != -1L
    }

    fun checkUser(username: String, password: String): Boolean {
        return readableDatabase.rawQuery(
            "SELECT 1 FROM $T_USERS WHERE $C_USERNAME=? AND $C_PASSWORD=?",
            arrayOf(username.trim(), password)
        ).use { c -> c.moveToFirst() }
    }

    // ===== Events (CRUD) =====
    fun insertEvent(name: String, date: String, location: String?): Long {
        val values = ContentValues().apply {
            put(C_NAME, name.trim())
            put(C_DATE, date.trim())
            put(C_LOCATION, location?.trim())
        }
        return writableDatabase.insert(T_EVENTS, null, values)
    }

    fun getAllEvents(): List<Event> {
        val out = mutableListOf<Event>()
        readableDatabase.rawQuery(
            "SELECT $C_ID, $C_NAME, $C_DATE, $C_LOCATION FROM $T_EVENTS ORDER BY $C_DATE ASC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Event(
                        id = c.getInt(0),
                        name = c.getString(1),
                        date = c.getString(2),
                        location = c.getString(3) ?: ""
                    )
                )
            }
        }
        return out
    }

    fun updateEvent(id: Int, name: String, date: String, location: String?): Int {
        val values = ContentValues().apply {
            put(C_NAME, name.trim())
            put(C_DATE, date.trim())
            put(C_LOCATION, location?.trim())
        }
        return writableDatabase.update(T_EVENTS, values, "$C_ID=?", arrayOf(id.toString()))
    }

    fun deleteEvent(id: Int): Int {
        return writableDatabase.delete(T_EVENTS, "$C_ID=?", arrayOf(id.toString()))
    }

    fun getNextUpcomingEvent(): Event? {
        readableDatabase.rawQuery(
            "SELECT $C_ID, $C_NAME, $C_DATE, $C_LOCATION FROM $T_EVENTS ORDER BY $C_DATE ASC LIMIT 1",
            null
        ).use { c ->
            return if (c.moveToFirst()) {
                Event(
                    id = c.getInt(0),
                    name = c.getString(1),
                    date = c.getString(2),
                    location = c.getString(3) ?: ""
                )
            } else null
        }
    }
}