package com.example.eventtrackingapp_dominoelamattina

/**
 * Simple model for an event record.
 */
data class Event(
    val id: Int,
    val name: String,
    val date: String,
    val location: String
)