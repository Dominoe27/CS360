package com.example.eventtrackingapp_dominoelamattina

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Launcher screen for login + signup. */
class LoginActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        db = DatabaseHelper(this)

        val username = findViewById<EditText>(R.id.editTextUsername)
        val password = findViewById<EditText>(R.id.editTextPassword)
        val btnLogin = findViewById<Button>(R.id.buttonLogin)
        val btnCreate = findViewById<Button>(R.id.buttonCreateAccount)

        btnLogin.setOnClickListener {
            val u = username.text.toString()
            val p = password.text.toString()
            if (db.checkUser(u, p)) {
                Toast.makeText(this, getString(R.string.toast_login_success), Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, EventListActivity::class.java))
            } else {
                Toast.makeText(this, getString(R.string.toast_login_invalid), Toast.LENGTH_SHORT).show()
            }
        }

        btnCreate.setOnClickListener {
            val u = username.text.toString()
            val p = password.text.toString()
            if (u.isBlank() || p.isBlank()) {
                Toast.makeText(this, getString(R.string.toast_enter_creds), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val ok = db.insertUser(u, p)
            if (ok) {
                Toast.makeText(this, getString(R.string.toast_account_created), Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, getString(R.string.toast_account_exists), Toast.LENGTH_SHORT).show()
            }
        }
    }
}