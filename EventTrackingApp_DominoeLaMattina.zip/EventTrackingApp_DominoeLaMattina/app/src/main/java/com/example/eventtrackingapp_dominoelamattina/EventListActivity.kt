package com.example.eventtrackingapp_dominoelamattina

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class EventListActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var recycler: RecyclerView
    private lateinit var adapter: EventAdapter

    private val requestSmsPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) promptPhoneAndSend()
        else toast(getString(R.string.toast_sms_permission_denied))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_list)

        db = DatabaseHelper(this)

        recycler = findViewById(R.id.recyclerViewEvents)
        recycler.layoutManager = GridLayoutManager(this, 2)
        adapter = EventAdapter(
            db.getAllEvents().toMutableList(),
            onClick = { e -> showUpdateDialog(e) },
            onLongClick = { e -> confirmDelete(e) }
        )
        recycler.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fabAddEvent).setOnClickListener {
            showAddDialog()
        }

        findViewById<Button>(R.id.buttonOpenSms).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
            ) {
                promptPhoneAndSend()
            } else {
                requestSmsPerm.launch(Manifest.permission.SEND_SMS)
            }
        }
    }

    private fun refresh() {
        adapter.replaceAll(db.getAllEvents())
    }

    private fun showAddDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_event, null)
        val name = view.findViewById<EditText>(R.id.inputEventName)
        val date = view.findViewById<EditText>(R.id.inputEventDate)
        val loc = view.findViewById<EditText>(R.id.inputEventLocation)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.add_event_title))
            .setView(view)
            .setPositiveButton(getString(R.string.label_save)) { _, _ ->
                val id = db.insertEvent(name.text.toString(), date.text.toString(), loc.text.toString())
                if (id != -1L) {
                    toast(getString(R.string.toast_event_added))
                    refresh()
                } else toast(getString(R.string.toast_event_failed))
            }
            .setNegativeButton(getString(R.string.label_cancel), null)
            .show()
    }

    private fun showUpdateDialog(e: Event) {
        val view = layoutInflater.inflate(R.layout.dialog_event, null)
        val name = view.findViewById<EditText>(R.id.inputEventName)
        val date = view.findViewById<EditText>(R.id.inputEventDate)
        val loc = view.findViewById<EditText>(R.id.inputEventLocation)

        name.setText(e.name)
        date.setText(e.date)
        loc.setText(e.location)

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.update_event_title))
            .setView(view)
            .setPositiveButton(getString(R.string.label_update)) { _, _ ->
                val rows = db.updateEvent(e.id, name.text.toString(), date.text.toString(), loc.text.toString())
                if (rows > 0) {
                    toast(getString(R.string.toast_event_updated))
                    refresh()
                } else toast(getString(R.string.toast_event_update_failed))
            }
            .setNeutralButton(getString(R.string.label_delete)) { _, _ -> confirmDelete(e) }
            .setNegativeButton(getString(R.string.label_cancel), null)
            .show()
    }

    private fun confirmDelete(e: Event) {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.delete_event_message, e.name))
            .setPositiveButton(getString(R.string.label_delete)) { _, _ ->
                val rows = db.deleteEvent(e.id)
                if (rows > 0) {
                    toast(getString(R.string.toast_event_deleted))
                    refresh()
                } else toast(getString(R.string.toast_event_delete_failed))
            }
            .setNegativeButton(getString(R.string.label_cancel), null)
            .show()
    }

    private fun promptPhoneAndSend() {
        val input = EditText(this).apply {
            hint = getString(R.string.hint_phone)
            inputType = InputType.TYPE_CLASS_PHONE
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.sms_reminder_title))
            .setMessage(getString(R.string.sms_reminder_message))
            .setView(input)
            .setPositiveButton(getString(R.string.label_send)) { _, _ ->
                val phone = input.text.toString()
                sendNextEventSms(phone)
            }
            .setNegativeButton(getString(R.string.label_cancel), null)
            .show()
    }

    private fun sendNextEventSms(phone: String) {
        val e = db.getNextUpcomingEvent()
        if (e == null) {
            toast(getString(R.string.toast_no_events))
            return
        }
        val msg = buildString {
            append("Reminder: ${e.name} on ${e.date}")
            if (e.location.isNotBlank()) append(" at ${e.location}")
        }
        try {
            val smsManager: SmsManager =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
            smsManager.sendTextMessage(phone.trim(), null, msg, null, null)
            toast(getString(R.string.toast_sms_sent))
        } catch (_: Exception) {
            toast(getString(R.string.toast_sms_failed))
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}