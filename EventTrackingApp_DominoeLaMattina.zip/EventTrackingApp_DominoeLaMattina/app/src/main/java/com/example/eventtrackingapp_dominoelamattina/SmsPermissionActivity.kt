package com.example.eventtrackingapp_dominoelamattina

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Simple screen to request SEND_SMS and show a result Toast.
 */
class SmsPermissionActivity : AppCompatActivity() {

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS Permission Denied.", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_permission)

        val grantButton = findViewById<Button>(R.id.buttonGrantSms)
        grantButton.setOnClickListener {
            when {
                ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED -> {
                    Toast.makeText(this, "Permission Already Granted", Toast.LENGTH_SHORT).show()
                }
                else -> requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
        }
    }
}